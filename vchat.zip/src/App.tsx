/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Plus, 
  MessageSquare, 
  Settings, 
  User, 
  Bot, 
  Copy, 
  Check,
  Menu,
  X,
  Trash2,
  LogOut
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";

// Initialize Gemini API
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface ChatHistory {
  id: string;
  title: string;
  lastMessage: string;
  timestamp: Date;
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [history, setHistory] = useState<ChatHistory[]>([
    { id: '1', title: 'Welcome to VChat', lastMessage: 'How can I help you today?', timestamp: new Date() },
    { id: '2', title: 'React Hooks Guide', lastMessage: 'Explain useEffect...', timestamp: new Date(Date.now() - 86400000) },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [...messages, userMessage].map(m => ({
          role: m.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: m.content }]
        })),
      });

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.text || "I'm sorry, I couldn't generate a response.",
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Error calling Gemini API:", error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: "Oops! Something went wrong. Please check your connection and try again.",
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const startNewChat = () => {
    setMessages([]);
    setInput('');
  };

  return (
    <div className="flex h-screen w-full bg-bg-main overflow-hidden font-sans">
      {/* Mobile Sidebar Toggle */}
      <button 
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-slate-800 rounded-lg text-slate-200 shadow-lg"
      >
        {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ 
          width: isSidebarOpen ? '260px' : '0px',
          x: isSidebarOpen ? 0 : -260
        }}
        className={`bg-bg-sidebar border-r border-glass-border flex flex-col z-40 fixed lg:relative h-full`}
      >
        <div className="p-5 flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-[#818cf8] to-primary rounded-lg flex items-center justify-center shadow-lg shadow-primary/20">
            <Bot size={20} className="text-white" />
          </div>
          <h1 className="text-[22px] font-bold text-text-main">
            VChat
          </h1>
        </div>

        <div className="px-5 mb-6">
          <button 
            onClick={startNewChat}
            className="w-full flex items-center gap-2.5 p-3 bg-transparent border border-glass-border rounded-xl hover:bg-white/5 transition-all text-sm font-medium text-text-main"
          >
            <Plus size={16} />
            New Chat
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 space-y-1">
          <p className="text-[11px] uppercase tracking-[0.1em] text-text-dim font-bold mb-3">Recent History</p>
          {history.map((chat) => (
            <button 
              key={chat.id}
              className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-all text-left group ${chat.id === '1' ? 'bg-white/5 text-text-main' : 'text-text-dim hover:bg-white/5 hover:text-text-main'}`}
            >
              <div className="flex-1 overflow-hidden">
                <p className="text-sm truncate">{chat.title}</p>
              </div>
            </button>
          ))}
        </div>

        <div className="p-5 border-t border-glass-border">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-slate-600 flex items-center justify-center">
              <User size={18} />
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-medium truncate">Alexander Chen</p>
              <p className="text-[11px] text-text-dim truncate">Pro Member</p>
            </div>
            <Settings size={14} className="text-text-dim cursor-pointer hover:text-text-main transition-colors" />
          </div>
        </div>
      </motion.aside>

      {/* Main Chat Area */}
      <main className="flex-1 flex flex-col relative min-w-0">
        {/* Header */}
        <header className="h-16 border-b border-glass-border flex items-center justify-between px-10 bg-bg-main/80 backdrop-blur-md sticky top-0 z-30">
          <div className="font-semibold text-[15px] text-text-main">
            {messages.length > 0 ? messages[0].content.substring(0, 30) + '...' : 'New Chat'}
          </div>
          <div className="px-2.5 py-1 bg-primary/10 text-[#a5b4fc] border border-primary/30 rounded-full text-xs">
            GPT-4o Advanced
          </div>
        </header>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-10 lg:px-[120px] lg:py-10 space-y-6">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-2xl mx-auto space-y-6">
              <motion.div 
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center text-primary"
              >
                <Bot size={32} />
              </motion.div>
              <div className="space-y-2">
                <h2 className="text-2xl font-bold text-white">How can I help you today?</h2>
                <p className="text-text-dim">VChat is your powerful AI assistant for coding, writing, and creative tasks.</p>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full">
                {[
                  "Write a React component for a card",
                  "Explain quantum computing simply",
                  "Plan a 3-day trip to Tokyo",
                  "Help me debug this Python code"
                ].map((suggestion, i) => (
                  <button 
                    key={i}
                    onClick={() => setInput(suggestion)}
                    className="p-4 bg-glass border border-glass-border rounded-xl text-sm text-left hover:bg-white/5 hover:border-primary/50 transition-all"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="w-full space-y-6">
              <AnimatePresence initial={false}>
                {messages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`group relative max-w-[80%] p-4 lg:p-5 rounded-2xl text-[15px] leading-[1.6] ${
                      msg.role === 'user' 
                        ? 'bg-primary text-white rounded-br-none' 
                        : 'bg-bg-sidebar border border-glass-border text-text-main rounded-bl-none shadow-lg'
                    }`}>
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                      
                      {msg.role === 'assistant' && (
                        <button 
                          onClick={() => copyToClipboard(msg.content, msg.id)}
                          className="absolute -right-10 top-0 p-2 text-text-dim hover:text-text-main transition-all opacity-0 group-hover:opacity-100"
                        >
                          {copiedId === msg.id ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                        </button>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              
              {isLoading && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex justify-start"
                >
                  <div className="bg-bg-sidebar border border-glass-border p-4 lg:p-5 rounded-2xl rounded-bl-none shadow-lg flex flex-col gap-2">
                    <div className="flex gap-1">
                      <span className="w-1.5 h-1.5 bg-text-dim rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                      <span className="w-1.5 h-1.5 bg-text-dim rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                      <span className="w-1.5 h-1.5 bg-text-dim rounded-full animate-bounce"></span>
                    </div>
                    <span className="text-xs text-text-dim">VChat is thinking...</span>
                  </div>
                </motion.div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input Area */}
        <div className="px-10 lg:px-[120px] pb-10 bg-gradient-to-t from-bg-main via-bg-main to-transparent">
          <div className="max-w-3xl mx-auto relative">
            <div className="relative group">
              <div className="flex items-center bg-glass backdrop-blur-xl border border-glass-border rounded-2xl p-3.5 shadow-2xl">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSend();
                    }
                  }}
                  placeholder="Ask VChat anything..."
                  rows={1}
                  className="flex-1 bg-transparent border-none outline-none text-text-main text-[15px] placeholder:text-text-dim px-2 resize-none max-h-48"
                  style={{ height: 'auto' }}
                  onInput={(e) => {
                    const target = e.target as HTMLTextAreaElement;
                    target.style.height = 'auto';
                    target.style.height = `${target.scrollHeight}px`;
                  }}
                />
                <button 
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  className={`w-8 h-8 flex items-center justify-center rounded-lg transition-all ${
                    input.trim() && !isLoading 
                      ? 'bg-primary text-white shadow-lg shadow-primary/20 hover:bg-primary-hover' 
                      : 'bg-slate-700 text-slate-500 cursor-not-allowed'
                  }`}
                >
                  <Send size={16} />
                </button>
              </div>
            </div>
            <p className="text-[12px] text-center mt-3 text-text-dim">
              VChat can make mistakes. Check important info.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
